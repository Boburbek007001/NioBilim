import type { BodySystem, HealthProblem } from "@shared/schema";
import { Severity } from "@shared/schema";

export interface IStorage {
  getAllSystems(): Promise<BodySystem[]>;
  getSystemById(id: string): Promise<BodySystem | undefined>;
  getProblemsBySystem(systemId: string): Promise<HealthProblem[]>;
  getProblemById(id: string): Promise<HealthProblem | undefined>;
  getFeaturedProblems(): Promise<HealthProblem[]>;
  getRelatedProblems(problemId: string): Promise<HealthProblem[]>;
  searchProblems(query: string): Promise<HealthProblem[]>;
}

export class MemStorage implements IStorage {
  private systems: Map<string, BodySystem>;
  private problems: Map<string, HealthProblem>;

  constructor() {
    this.systems = new Map();
    this.problems = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize 30 body systems
    const systemsData: BodySystem[] = [
      {
        id: "cardiovascular",
        name: {
          uz: "Yurak-qon tomir tizimi",
          en: "Cardiovascular System",
          ru: "Сердечно-сосудистая система"
        },
        icon: "heart",
        description: {
          uz: "Yurak va qon tomirlari orqali tanaga qon aylanishini ta'minlaydi",
          en: "Circulates blood throughout the body via the heart and blood vessels",
          ru: "Обеспечивает циркуляцию крови по всему телу через сердце и кровеносные сосуды"
        },
        problemCount: 120,
        color: "#e74c3c"
      },
      {
        id: "nervous",
        name: {
          uz: "Asab tizimi",
          en: "Nervous System",
          ru: "Нервная система"
        },
        icon: "brain",
        description: {
          uz: "Miya va asablar orqali signallarni uzatadi va harakatlarni boshqaradi",
          en: "Transmits signals through the brain and nerves to control body functions",
          ru: "Передает сигналы через мозг и нервы для управления функциями организма"
        },
        problemCount: 150,
        color: "#9b59b6"
      },
      {
        id: "respiratory",
        name: {
          uz: "Nafas olish tizimi",
          en: "Respiratory System",
          ru: "Дыхательная система"
        },
        icon: "wind",
        description: {
          uz: "O'pkalar orqali kislorod olish va karbonat angidridni chiqarishni ta'minlaydi",
          en: "Enables oxygen intake and carbon dioxide expulsion through the lungs",
          ru: "Обеспечивает поглощение кислорода и выделение углекислого газа через легкие"
        },
        problemCount: 100,
        color: "#3498db"
      },
      {
        id: "digestive",
        name: {
          uz: "Ovqat hazm qilish tizimi",
          en: "Digestive System",
          ru: "Пищеварительная система"
        },
        icon: "utensils",
        description: {
          uz: "Ovqatni parchalab, oziq moddalarni shimib olishni ta'minlaydi",
          en: "Breaks down food and absorbs nutrients for the body",
          ru: "Расщепляет пищу и обеспечивает усвоение питательных веществ"
        },
        problemCount: 110,
        color: "#e67e22"
      },
      {
        id: "endocrine",
        name: {
          uz: "Endokrin tizim",
          en: "Endocrine System",
          ru: "Эндокринная система"
        },
        icon: "droplet",
        description: {
          uz: "Gormonlar orqali tananing turli funktsiyalarini boshqaradi",
          en: "Regulates body functions through hormone secretion",
          ru: "Регулирует функции организма через выделение гормонов"
        },
        problemCount: 95,
        color: "#1abc9c"
      },
      {
        id: "skeletal",
        name: {
          uz: "Skelet tizimi",
          en: "Skeletal System",
          ru: "Скелетная система"
        },
        icon: "bone",
        description: {
          uz: "Suyaklar va bo'g'imlar orqali tanaga qo'llab-quvvatlash beradi",
          en: "Provides structural support through bones and joints",
          ru: "Обеспечивает структурную поддержку через кости и суставы"
        },
        problemCount: 105,
        color: "#95a5a6"
      },
      {
        id: "muscular",
        name: {
          uz: "Mushak tizimi",
          en: "Muscular System",
          ru: "Мышечная система"
        },
        icon: "activity",
        description: {
          uz: "Harakatlanish va kuch ishlab chiqarishni ta'minlaydi",
          en: "Enables movement and force production through muscles",
          ru: "Обеспечивает движение и выработку силы через мышцы"
        },
        problemCount: 100,
        color: "#d35400"
      },
      {
        id: "urinary",
        name: {
          uz: "Siydik chiqarish tizimi",
          en: "Urinary System",
          ru: "Мочевыделительная система"
        },
        icon: "droplets",
        description: {
          uz: "Chiqindilarni filtrlash va siydik orqali chiqarishni ta'minlaydi",
          en: "Filters waste and expels it through urine",
          ru: "Фильтрует отходы и выводит их через мочу"
        },
        problemCount: 90,
        color: "#f39c12"
      },
      {
        id: "reproductive",
        name: {
          uz: "Ko'payish tizimi",
          en: "Reproductive System",
          ru: "Репродуктивная система"
        },
        icon: "users",
        description: {
          uz: "Naslni davom ettirish funktsiyasini bajaradi",
          en: "Enables reproduction and continuation of species",
          ru: "Обеспечивает размножение и продолжение рода"
        },
        problemCount: 85,
        color: "#e91e63"
      },
      {
        id: "immune",
        name: {
          uz: "Immunitet tizimi",
          en: "Immune System",
          ru: "Иммунная система"
        },
        icon: "shield",
        description: {
          uz: "Tanani infeksiyalar va kasalliklardan himoya qiladi",
          en: "Protects the body from infections and diseases",
          ru: "Защищает организм от инфекций и заболеваний"
        },
        problemCount: 115,
        color: "#27ae60"
      },
      {
        id: "integumentary",
        name: {
          uz: "Teri tizimi",
          en: "Integumentary System",
          ru: "Покровная система"
        },
        icon: "hand",
        description: {
          uz: "Teri, soch va tirnoqlar orqali tanani himoya qiladi",
          en: "Protects the body through skin, hair, and nails",
          ru: "Защищает организм через кожу, волосы и ногти"
        },
        problemCount: 100,
        color: "#f4a460"
      },
      {
        id: "lymphatic",
        name: {
          uz: "Limfa tizimi",
          en: "Lymphatic System",
          ru: "Лимфатическая система"
        },
        icon: "droplet",
        description: {
          uz: "Suyuqliklarni muvozanatlash va immunitetni qo'llab-quvvatlaydi",
          en: "Balances fluids and supports immune function",
          ru: "Балансирует жидкости и поддерживает иммунную функцию"
        },
        problemCount: 80,
        color: "#16a085"
      },
      {
        id: "visual",
        name: {
          uz: "Ko'rish tizimi",
          en: "Visual System",
          ru: "Зрительная система"
        },
        icon: "eye",
        description: {
          uz: "Ko'z orqali ko'rish qobiliyatini ta'minlaydi",
          en: "Enables vision through the eyes",
          ru: "Обеспечивает зрение через глаза"
        },
        problemCount: 95,
        color: "#2980b9"
      },
      {
        id: "auditory",
        name: {
          uz: "Eshitish tizimi",
          en: "Auditory System",
          ru: "Слуховая система"
        },
        icon: "ear",
        description: {
          uz: "Quloq orqali eshitish qobiliyatini ta'minlaydi",
          en: "Enables hearing through the ears",
          ru: "Обеспечивает слух через уши"
        },
        problemCount: 85,
        color: "#8e44ad"
      },
      {
        id: "olfactory",
        name: {
          uz: "Hid bilish tizimi",
          en: "Olfactory System",
          ru: "Обонятельная система"
        },
        icon: "nose",
        description: {
          uz: "Burun orqali hidlarni sezishni ta'minlaydi",
          en: "Detects smells through the nose",
          ru: "Определяет запахи через нос"
        },
        problemCount: 70,
        color: "#16a085"
      },
      {
        id: "gustatory",
        name: {
          uz: "Ta'm bilish tizimi",
          en: "Gustatory System",
          ru: "Вкусовая система"
        },
        icon: "tongue",
        description: {
          uz: "Til orqali ta'mlarni sezishni ta'minlaydi",
          en: "Detects tastes through the tongue",
          ru: "Определяет вкусы через язык"
        },
        problemCount: 65,
        color: "#c0392b"
      },
      {
        id: "vestibular",
        name: {
          uz: "Muvozanat tizimi",
          en: "Vestibular System",
          ru: "Вестибулярная система"
        },
        icon: "balance",
        description: {
          uz: "Muvozanat va fazoviy yo'nalishni ta'minlaydi",
          en: "Maintains balance and spatial orientation",
          ru: "Поддерживает равновесие и пространственную ориентацию"
        },
        problemCount: 75,
        color: "#34495e"
      },
      {
        id: "circulatory",
        name: {
          uz: "Qon aylanish tizimi",
          en: "Circulatory System",
          ru: "Кровеносная система"
        },
        icon: "activity",
        description: {
          uz: "Qon aylanishini va oziq moddalarni tashishni ta'minlaydi",
          en: "Circulates blood and transports nutrients",
          ru: "Обеспечивает циркуляцию крови и транспортировку питательных веществ"
        },
        problemCount: 110,
        color: "#c0392b"
      },
      {
        id: "hepatic",
        name: {
          uz: "Jigar tizimi",
          en: "Hepatic System",
          ru: "Печеночная система"
        },
        icon: "square",
        description: {
          uz: "Jigar orqali zaharlanishdan tozalash va metabolizmni boshqaradi",
          en: "Detoxifies and regulates metabolism through the liver",
          ru: "Детоксифицирует и регулирует обмен веществ через печень"
        },
        problemCount: 90,
        color: "#8b4513"
      },
      {
        id: "pancreatic",
        name: {
          uz: "Oshqozon osti bezi tizimi",
          en: "Pancreatic System",
          ru: "Панкреатическая система"
        },
        icon: "droplet",
        description: {
          uz: "Insulin ishlab chiqarish va hazm enzimlarini ta'minlaydi",
          en: "Produces insulin and digestive enzymes",
          ru: "Вырабатывает инсулин и пищеварительные ферменты"
        },
        problemCount: 80,
        color: "#d68910"
      },
      {
        id: "renal",
        name: {
          uz: "Buyrak tizimi",
          en: "Renal System",
          ru: "Почечная система"
        },
        icon: "filter",
        description: {
          uz: "Suyuqliklar va elektrolitlarni muvozanatlashni ta'minlaydi",
          en: "Filters blood and balances fluids and electrolytes",
          ru: "Фильтрует кровь и балансирует жидкости и электролиты"
        },
        problemCount: 95,
        color: "#7d3c98"
      },
      {
        id: "hematopoietic",
        name: {
          uz: "Qon hosil qilish tizimi",
          en: "Hematopoietic System",
          ru: "Кроветворная система"
        },
        icon: "droplets",
        description: {
          uz: "Qon hujayralarini ishlab chiqarishni ta'minlaydi",
          en: "Produces blood cells in bone marrow",
          ru: "Производит клетки крови в костном мозге"
        },
        problemCount: 85,
        color: "#922b21"
      },
      {
        id: "thermoregulatory",
        name: {
          uz: "Haroratni tartibga solish tizimi",
          en: "Thermoregulatory System",
          ru: "Терморегуляторная система"
        },
        icon: "thermometer",
        description: {
          uz: "Tana haroratini tartibga solishni ta'minlaydi",
          en: "Regulates body temperature",
          ru: "Регулирует температуру тела"
        },
        problemCount: 70,
        color: "#e74c3c"
      },
      {
        id: "metabolic",
        name: {
          uz: "Metabolizm tizimi",
          en: "Metabolic System",
          ru: "Метаболическая система"
        },
        icon: "zap",
        description: {
          uz: "Energiya ishlab chiqarish va moddalar almashinuvini boshqaradi",
          en: "Manages energy production and material exchange",
          ru: "Управляет производством энергии и обменом веществ"
        },
        problemCount: 100,
        color: "#f39c12"
      },
      {
        id: "hormonal",
        name: {
          uz: "Gormon tizimi",
          en: "Hormonal System",
          ru: "Гормональная система"
        },
        icon: "activity",
        description: {
          uz: "Gormonlar orqali tananing barcha funktsiyalarini boshqaradi",
          en: "Controls all body functions through hormones",
          ru: "Управляет всеми функциями организма через гормоны"
        },
        problemCount: 105,
        color: "#16a085"
      },
      {
        id: "excretory",
        name: {
          uz: "Chiqarish tizimi",
          en: "Excretory System",
          ru: "Выделительная система"
        },
        icon: "trash",
        description: {
          uz: "Tanadan chiqindilarni chiqarishni ta'minlaydi",
          en: "Eliminates waste products from the body",
          ru: "Выводит продукты отходов из организма"
        },
        problemCount: 85,
        color: "#95a5a6"
      },
      {
        id: "psychological",
        name: {
          uz: "Psixologik tizim",
          en: "Psychological System",
          ru: "Психологическая система"
        },
        icon: "brain",
        description: {
          uz: "Ruhiy salomatlik va emotsional holatni boshqaradi",
          en: "Manages mental health and emotional well-being",
          ru: "Управляет психическим здоровьем и эмоциональным состоянием"
        },
        problemCount: 130,
        color: "#5d6d7e"
      },
      {
        id: "nutritional",
        name: {
          uz: "Ovqatlanish tizimi",
          en: "Nutritional System",
          ru: "Пищевая система"
        },
        icon: "apple",
        description: {
          uz: "Oziq moddalarni qabul qilish va ulardan foydalanishni ta'minlaydi",
          en: "Manages nutrient intake and utilization",
          ru: "Управляет потреблением и использованием питательных веществ"
        },
        problemCount: 120,
        color: "#27ae60"
      },
      {
        id: "sleep",
        name: {
          uz: "Uyqu tizimi",
          en: "Sleep System",
          ru: "Система сна"
        },
        icon: "moon",
        description: {
          uz: "Uyqu va dam olish tsikllarini tartibga soladi",
          en: "Regulates sleep and rest cycles",
          ru: "Регулирует циклы сна и отдыха"
        },
        problemCount: 75,
        color: "#34495e"
      },
      {
        id: "cognitive",
        name: {
          uz: "Kognitiv tizim",
          en: "Cognitive System",
          ru: "Когнитивная система"
        },
        icon: "lightbulb",
        description: {
          uz: "Fikrlash, xotira va o'rganish qobiliyatlarini ta'minlaydi",
          en: "Enables thinking, memory, and learning abilities",
          ru: "Обеспечивает мышление, память и способность к обучению"
        },
        problemCount: 110,
        color: "#f4d03f"
      }
    ];

    systemsData.forEach(system => {
      this.systems.set(system.id, system);
    });

    // Initialize featured problems (overweight, depression, stress) and many more
    const problemsData: HealthProblem[] = [
      // Featured: Overweight
      {
        id: "overweight",
        systemId: "nutritional",
        name: {
          uz: "Ortiqcha vazn",
          en: "Overweight and Obesity",
          ru: "Избыточный вес и ожирение"
        },
        severity: Severity.HIGH,
        description: {
          uz: "Tanada ortiqcha yog' to'planishi va sog'liqqa salbiy ta'sir ko'rsatishi",
          en: "Excessive fat accumulation that negatively impacts health",
          ru: "Избыточное накопление жира, негативно влияющее на здоровье"
        },
        quickSummary: {
          uz: "Noto'g'ri ovqatlanish va kam harakatlanish natijasida ortiqcha vazn paydo bo'ladi",
          en: "Results from poor diet and lack of physical activity",
          ru: "Результат неправильного питания и недостатка физической активности"
        },
        overview: {
          uz: "Ortiqcha vazn - bu tana massasi indeksi (BMI) 25-29.9 oralig'ida bo'lgan holat. Semizlik esa BMI 30 dan yuqori bo'lganda boshlanadi. Bu holat yurak kasalliklari, diabet, qo'shma og'riqlari va boshqa jiddiy sog'liq muammolariga olib kelishi mumkin.",
          en: "Overweight is defined as having a Body Mass Index (BMI) between 25-29.9, while obesity begins at BMI 30 or higher. This condition increases risk of heart disease, diabetes, joint pain, and many other serious health problems.",
          ru: "Избыточный вес определяется индексом массы тела (ИМТ) от 25 до 29,9, а ожирение начинается при ИМТ 30 и выше. Это состояние увеличивает риск сердечных заболеваний, диабета, боли в суставах и многих других серьезных проблем со здоровьем."
        },
        causes: {
          uz: [
            "Yuqori kaloriyali va kam faol ovqatlanish",
            "Jismoniy faoliyat etishmasligi",
            "Genetik omillar",
            "Uyqu buzilishi",
            "Stress va emotsional ovqatlanish",
            "Dori-darmonlar ta'siri",
            "Gormon muvozanati buzilishi"
          ],
          en: [
            "High-calorie diet with low nutritional value",
            "Insufficient physical activity",
            "Genetic factors",
            "Sleep disorders",
            "Stress and emotional eating",
            "Side effects of medications",
            "Hormonal imbalances"
          ],
          ru: [
            "Высококалорийная диета с низкой пищевой ценностью",
            "Недостаточная физическая активность",
            "Генетические факторы",
            "Нарушения сна",
            "Стресс и эмоциональное переедание",
            "Побочные эффекты лекарств",
            "Гормональный дисбаланс"
          ]
        },
        symptoms: {
          uz: [
            "Tez charchash",
            "Nafas qisilishi",
            "Terlash",
            "Qo'shmalarda og'riq",
            "Kam harakatlilik",
            "O'zini yomon his qilish",
            "Uyqusizlik"
          ],
          en: [
            "Fatigue and low energy",
            "Shortness of breath",
            "Excessive sweating",
            "Joint pain",
            "Reduced mobility",
            "Low self-esteem",
            "Sleep apnea"
          ],
          ru: [
            "Усталость и низкая энергия",
            "Одышка",
            "Чрезмерное потоотделение",
            "Боль в суставах",
            "Снижение подвижности",
            "Низкая самооценка",
            "Апноэ во сне"
          ]
        },
        solutions: {
          uz: [
            "Kun davomida 5-6 marta oz-oz ovqatlaning, ortiqcha ovqatlanmang",
            "Har kuni kamida 30 daqiqa jismoniy mashq qiling (yurish, yugurish, suzish)",
            "Sog'lom ovqatlanish rejasini tuzing: ko'proq sabzavot, meva, to'liq donli mahsulotlar",
            "Shakar va qayta ishlangan ovqatlarni kamaytiring",
            "Kunlik suv iste'molini oshiring (8-10 stakan)",
            "Yetarli uyqu oling (7-9 soat)",
            "Stress darajasini kamaytiring: meditatsiya, yoga",
            "Ovqatlanish kundaligini yuritib, o'zingizni nazorat qiling",
            "Dietolog va shifokordan maslahat oling"
          ],
          en: [
            "Eat 5-6 smaller meals throughout the day instead of large portions",
            "Exercise at least 30 minutes daily (walking, jogging, swimming)",
            "Create a healthy eating plan: more vegetables, fruits, whole grains",
            "Reduce sugar and processed foods",
            "Increase daily water intake (8-10 glasses)",
            "Get adequate sleep (7-9 hours)",
            "Reduce stress levels through meditation and yoga",
            "Keep a food diary for self-monitoring",
            "Consult a dietitian and physician for personalized guidance"
          ],
          ru: [
            "Ешьте 5-6 раз небольшими порциями в течение дня",
            "Занимайтесь физической активностью минимум 30 минут ежедневно",
            "Создайте план здорового питания: больше овощей, фруктов, цельнозерновых",
            "Сократите сахар и обработанные продукты",
            "Увеличьте потребление воды (8-10 стаканов в день)",
            "Получайте достаточный сон (7-9 часов)",
            "Снизьте уровень стресса через медитацию и йогу",
            "Ведите дневник питания для самоконтроля",
            "Проконсультируйтесь с диетологом и врачом"
          ]
        },
        prevention: {
          uz: [
            "Muntazam ovqatlanish rejimini saqlang",
            "Har kuni harakatda bo'ling",
            "Vazningizni muntazam o'lchab turing",
            "Sog'lom ovqatlanish odatlarini shakllantiring",
            "Stress bilan to'g'ri kurashing"
          ],
          en: [
            "Maintain a regular eating schedule",
            "Stay active every day",
            "Monitor your weight regularly",
            "Develop healthy eating habits",
            "Manage stress effectively"
          ],
          ru: [
            "Поддерживайте регулярный режим питания",
            "Будьте активны каждый день",
            "Регулярно контролируйте свой вес",
            "Развивайте здоровые привычки питания",
            "Эффективно управляйте стрессом"
          ]
        },
        relatedProblems: ["diabetes", "hypertension", "sleep-apnea"],
        isFeatured: true
      },
      // Featured: Depression
      {
        id: "depression",
        systemId: "psychological",
        name: {
          uz: "Depressiya",
          en: "Depression",
          ru: "Депрессия"
        },
        severity: Severity.CRITICAL,
        description: {
          uz: "Uzoq davom etadigan qayg'u, umidsizlik va hayotdan zavq olmay qolish",
          en: "Persistent sadness, hopelessness, and loss of interest in life",
          ru: "Устойчивая грусть, безнадежность и потеря интереса к жизни"
        },
        quickSummary: {
          uz: "Ruhiy salomatlikka jiddiy ta'sir ko'rsatadigan emotsional buzilish",
          en: "A serious mood disorder affecting mental health and daily functioning",
          ru: "Серьезное расстройство настроения, влияющее на психическое здоровье"
        },
        overview: {
          uz: "Depressiya - bu ruhiy kasallik bo'lib, unda odam doimiy ravishda xafa, umidsiz his qiladi va hayotdan zavq olmay qoladi. Bu holat kundalik faoliyatga, ishlashga, uxlashga va ovqatlanishga jiddiy ta'sir ko'rsatadi. Depressiya davolash mumkin bo'lgan kasallik.",
          en: "Depression is a mental health condition characterized by persistent feelings of sadness, hopelessness, and loss of interest in previously enjoyed activities. It significantly impacts daily functioning, work, sleep, and eating patterns. Depression is a treatable condition.",
          ru: "Депрессия - это психическое заболевание, характеризующееся устойчивыми чувствами грусти, безнадежности и потери интереса к ранее приятной деятельности. Она значительно влияет на повседневное функционирование, работу, сон и питание."
        },
        causes: {
          uz: [
            "Genetik moyillik",
            "Miyada kimyoviy muvozanat buzilishi",
            "Stressli hayotiy voqealar",
            "Travma yoki yo'qotishlar",
            "Surunkali kasalliklar",
            "Dori-darmonlar ta'siri",
            "Ijtimoiy izolyatsiya"
          ],
          en: [
            "Genetic predisposition",
            "Chemical imbalances in the brain",
            "Stressful life events",
            "Trauma or loss",
            "Chronic medical conditions",
            "Medication side effects",
            "Social isolation"
          ],
          ru: [
            "Генетическая предрасположенность",
            "Химический дисбаланс в мозге",
            "Стрессовые жизненные события",
            "Травма или потеря",
            "Хронические заболевания",
            "Побочные эффекты лекарств",
            "Социальная изоляция"
          ]
        },
        symptoms: {
          uz: [
            "Doimiy qayg'u va umidsizlik hissi",
            "Hayotdan zavq olmay qolish",
            "Energiya yo'qligi va charchoq",
            "Uyqu buzilishi",
            "Ishtaha o'zgarishi",
            "Diqqatni jamlashda qiyinchilik",
            "O'z-o'zini aybdor his qilish",
            "O'lim haqida o'ylash"
          ],
          en: [
            "Persistent sadness and hopelessness",
            "Loss of interest in activities",
            "Lack of energy and fatigue",
            "Sleep disturbances",
            "Changes in appetite",
            "Difficulty concentrating",
            "Feelings of guilt or worthlessness",
            "Thoughts of death or suicide"
          ],
          ru: [
            "Постоянная грусть и безнадежность",
            "Потеря интереса к деятельности",
            "Недостаток энергии и усталость",
            "Нарушения сна",
            "Изменения аппетита",
            "Трудности с концентрацией",
            "Чувство вины или бесполезности",
            "Мысли о смерти или самоубийстве"
          ]
        },
        solutions: {
          uz: [
            "Professional psixoterapiya (kognitiv-xulq-atvor terapiyasi)",
            "Shifokor tomonidan buyurilgan antidepressantlar",
            "Muntazam jismoniy mashqlar (endorfinlarni oshiradi)",
            "Sog'lom ovqatlanish va yetarli uyqu",
            "Yaqinlar va do'stlar bilan muloqot qiling",
            "Meditatsiya va bo'shashish texnikalari",
            "Maqsad va jadval tuzing",
            "Qo'llab-quvvatlash guruhlariga qo'shiling",
            "Stress omillarini kamaytiring",
            "Kundalik hayotda kichik yutuqlarga e'tibor bering"
          ],
          en: [
            "Professional psychotherapy (cognitive behavioral therapy)",
            "Antidepressant medications prescribed by a doctor",
            "Regular physical exercise (increases endorphins)",
            "Healthy diet and adequate sleep",
            "Connect with family and friends",
            "Meditation and relaxation techniques",
            "Set goals and maintain a routine",
            "Join support groups",
            "Reduce stress factors",
            "Focus on small daily achievements"
          ],
          ru: [
            "Профессиональная психотерапия (когнитивно-поведенческая терапия)",
            "Антидепрессанты, назначенные врачом",
            "Регулярные физические упражнения (увеличивают эндорфины)",
            "Здоровое питание и достаточный сон",
            "Общение с семьей и друзьями",
            "Медитация и техники релаксации",
            "Ставьте цели и поддерживайте распорядок",
            "Присоединяйтесь к группам поддержки",
            "Снижайте стресс-факторы",
            "Фокусируйтесь на маленьких ежедневных достижениях"
          ]
        },
        prevention: {
          uz: [
            "Stress bilan to'g'ri kurashishni o'rganing",
            "Sog'lom turmush tarzini saqlang",
            "Yetarli uyqu oling",
            "Ijtimoiy aloqalarni saqlab qoling",
            "Yordam so'rashdan qo'rqmang"
          ],
          en: [
            "Learn effective stress management",
            "Maintain a healthy lifestyle",
            "Get adequate sleep",
            "Maintain social connections",
            "Don't hesitate to seek help"
          ],
          ru: [
            "Научитесь эффективно управлять стрессом",
            "Поддерживайте здоровый образ жизни",
            "Получайте достаточный сон",
            "Поддерживайте социальные связи",
            "Не стесняйтесь обращаться за помощью"
          ]
        },
        relatedProblems: ["anxiety", "stress", "insomnia"],
        isFeatured: true
      },
      // Featured: Stress
      {
        id: "stress",
        systemId: "psychological",
        name: {
          uz: "Stress",
          en: "Chronic Stress",
          ru: "Хронический стресс"
        },
        severity: Severity.HIGH,
        description: {
          uz: "Uzoq davom etadigan taranglik va xavotir holati",
          en: "Prolonged state of tension and worry affecting overall health",
          ru: "Продолжительное состояние напряжения и беспокойства"
        },
        quickSummary: {
          uz: "Doimiy bosim va taranglik sog'liq va hayot sifatiga salbiy ta'sir qiladi",
          en: "Constant pressure and tension negatively impacts health and quality of life",
          ru: "Постоянное давление и напряжение негативно влияют на здоровье"
        },
        overview: {
          uz: "Stress - bu tananing turli xil talablarga bergan javobidir. Qisqa muddatli stress foydali bo'lishi mumkin, ammo uzoq davom etadigan (surunkali) stress jismoniy va ruhiy sog'liqqa jiddiy zarar yetkazadi. U yurak kasalliklari, gipertenziya, diabet va ruhiy buzilishlar xavfini oshiradi.",
          en: "Stress is the body's response to various demands. While short-term stress can be beneficial, chronic or prolonged stress seriously damages physical and mental health. It increases the risk of heart disease, hypertension, diabetes, and mental disorders.",
          ru: "Стресс - это реакция организма на различные требования. Хотя кратковременный стресс может быть полезным, хронический стресс серьезно вредит физическому и психическому здоровью, увеличивая риск сердечных заболеваний, гипертонии, диабета и психических расстройств."
        },
        causes: {
          uz: [
            "Ish bosimi va ortiqcha yuklama",
            "Moliyaviy qiyinchiliklar",
            "Oilaviy muammolar",
            "Sog'liq muammolari",
            "Katta hayotiy o'zgarishlar",
            "Vaqt taqchilligi",
            "Ijtimoiy munosabatlardagi muammolar"
          ],
          en: [
            "Work pressure and overload",
            "Financial difficulties",
            "Family problems",
            "Health concerns",
            "Major life changes",
            "Time constraints",
            "Relationship issues"
          ],
          ru: [
            "Рабочее давление и перегрузка",
            "Финансовые трудности",
            "Семейные проблемы",
            "Проблемы со здоровьем",
            "Крупные жизненные изменения",
            "Нехватка времени",
            "Проблемы в отношениях"
          ]
        },
        symptoms: {
          uz: [
            "Bosh og'rig'i",
            "Mushak tarangligi",
            "Charchoq",
            "Uyqu buzilishi",
            "Ishtaha o'zgarishi",
            "G'azablanish va asabiylashish",
            "Diqqatni jamlashda qiyinchilik",
            "Yurak urishi tezlashishi"
          ],
          en: [
            "Headaches",
            "Muscle tension",
            "Fatigue",
            "Sleep problems",
            "Changes in appetite",
            "Irritability and anger",
            "Difficulty concentrating",
            "Rapid heartbeat"
          ],
          ru: [
            "Головные боли",
            "Мышечное напряжение",
            "Усталость",
            "Проблемы со сном",
            "Изменения аппетита",
            "Раздражительность и гнев",
            "Трудности с концентрацией",
            "Учащенное сердцебиение"
          ]
        },
        solutions: {
          uz: [
            "Chuqur nafas olish mashqlari (4-7-8 texnikasi)",
            "Muntazam jismoniy mashqlar (yoga, yurish)",
            "Meditatsiya va onglilik amaliyoti",
            "Vaqtni to'g'ri boshqarish",
            "Ijobiy fikrlashni rivojlantiring",
            "Yetarli dam oling va ta'til qiling",
            "Sevimli mashg'ulotlar bilan shug'ullaning",
            "Professional maslahat (psixolog, terapevt)",
            "Ijtimoiy qo'llab-quvvatlashni qidiring",
            "Kofein va alkogolni kamaytiring"
          ],
          en: [
            "Deep breathing exercises (4-7-8 technique)",
            "Regular physical exercise (yoga, walking)",
            "Meditation and mindfulness practice",
            "Effective time management",
            "Develop positive thinking",
            "Take adequate rest and vacations",
            "Engage in enjoyable hobbies",
            "Professional counseling (psychologist, therapist)",
            "Seek social support",
            "Reduce caffeine and alcohol"
          ],
          ru: [
            "Упражнения глубокого дыхания (техника 4-7-8)",
            "Регулярные физические упражнения (йога, ходьба)",
            "Медитация и практика осознанности",
            "Эффективное управление временем",
            "Развивайте позитивное мышление",
            "Достаточный отдых и отпуска",
            "Занимайтесь любимыми хобби",
            "Профессиональное консультирование",
            "Ищите социальную поддержку",
            "Сократите кофеин и алкоголь"
          ]
        },
        prevention: {
          uz: [
            "Kun tartibini tuzing va rioya qiling",
            "Realistik maqsadlar qo'ying",
            "\"Yo'q\" deyishni o'rganing",
            "Sog'lom turmush tarzini saqlang",
            "Muntazam dam oling"
          ],
          en: [
            "Establish and maintain a daily routine",
            "Set realistic goals",
            "Learn to say 'no'",
            "Maintain a healthy lifestyle",
            "Take regular breaks"
          ],
          ru: [
            "Установите и поддерживайте ежедневный распорядок",
            "Ставьте реалистичные цели",
            "Научитесь говорить 'нет'",
            "Поддерживайте здоровый образ жизни",
            "Делайте регулярные перерывы"
          ]
        },
        relatedProblems: ["anxiety", "depression", "hypertension"],
        isFeatured: true
      }
    ];

    // Add more cardiovascular problems
    const cardiovascularProblems: Partial<HealthProblem>[] = [
      {
        id: "hypertension",
        systemId: "cardiovascular",
        name: { uz: "Gipertenziya", en: "Hypertension", ru: "Гипертония" },
        severity: Severity.HIGH,
        quickSummary: { uz: "Yuqori qon bosimi", en: "High blood pressure", ru: "Высокое кровяное давление" }
      },
      {
        id: "arrhythmia",
        systemId: "cardiovascular",
        name: { uz: "Aritmiya", en: "Arrhythmia", ru: "Аритмия" },
        severity: Severity.MODERATE,
        quickSummary: { uz: "Yurak urish ritmi buzilishi", en: "Irregular heartbeat", ru: "Нерегулярное сердцебиение" }
      }
    ];

    // Add nervous system problems
    const nervousProblems: Partial<HealthProblem>[] = [
      {
        id: "anxiety",
        systemId: "nervous",
        name: { uz: "Tashvish", en: "Anxiety Disorder", ru: "Тревожное расстройство" },
        severity: Severity.MODERATE,
        quickSummary: { uz: "Doimiy tashvish va xavotir", en: "Persistent worry and fear", ru: "Постоянное беспокойство и страх" }
      },
      {
        id: "insomnia",
        systemId: "sleep",
        name: { uz: "Uyqusizlik", en: "Insomnia", ru: "Бессонница" },
        severity: Severity.MODERATE,
        quickSummary: { uz: "Uxlashda qiyinchilik", en: "Difficulty sleeping", ru: "Трудности со сном" }
      }
    ];

    // Add digestive problems
    const digestiveProblems: Partial<HealthProblem>[] = [
      {
        id: "gastritis",
        systemId: "digestive",
        name: { uz: "Gastrit", en: "Gastritis", ru: "Гастрит" },
        severity: Severity.MODERATE,
        quickSummary: { uz: "Oshqozon shilliq qavatining yallig'lanishi", en: "Stomach lining inflammation", ru: "Воспаление слизистой желудка" }
      },
      {
        id: "ibs",
        systemId: "digestive",
        name: { uz: "Ichak sindiromi", en: "Irritable Bowel Syndrome", ru: "Синдром раздраженного кишечника" },
        severity: Severity.MODERATE,
        quickSummary: { uz: "Surunkali ichak buzilishi", en: "Chronic intestinal disorder", ru: "Хроническое расстройство кишечника" }
      }
    ];

    // Create complete problem objects with default values
    const createCompleteProblem = (partial: Partial<HealthProblem>): HealthProblem => ({
      id: partial.id || '',
      systemId: partial.systemId || '',
      name: partial.name || { uz: '', en: '', ru: '' },
      severity: partial.severity || Severity.LOW,
      description: partial.description || partial.quickSummary || { uz: '', en: '', ru: '' },
      quickSummary: partial.quickSummary || { uz: '', en: '', ru: '' },
      overview: partial.overview || partial.quickSummary || { uz: '', en: '', ru: '' },
      causes: partial.causes || { uz: [], en: [], ru: [] },
      symptoms: partial.symptoms || { uz: [], en: [], ru: [] },
      solutions: partial.solutions || { uz: [], en: [], ru: [] },
      prevention: partial.prevention || { uz: [], en: [], ru: [] },
      relatedProblems: partial.relatedProblems || [],
      isFeatured: partial.isFeatured || false
    });

    // Add all problems
    [...problemsData, ...cardiovascularProblems.map(createCompleteProblem), 
     ...nervousProblems.map(createCompleteProblem), 
     ...digestiveProblems.map(createCompleteProblem)].forEach(problem => {
      this.problems.set(problem.id, problem);
    });
  }

  async getAllSystems(): Promise<BodySystem[]> {
    return Array.from(this.systems.values());
  }

  async getSystemById(id: string): Promise<BodySystem | undefined> {
    return this.systems.get(id);
  }

  async getProblemsBySystem(systemId: string): Promise<HealthProblem[]> {
    return Array.from(this.problems.values()).filter(
      problem => problem.systemId === systemId
    );
  }

  async getProblemById(id: string): Promise<HealthProblem | undefined> {
    return this.problems.get(id);
  }

  async getFeaturedProblems(): Promise<HealthProblem[]> {
    return Array.from(this.problems.values()).filter(
      problem => problem.isFeatured === true
    );
  }

  async getRelatedProblems(problemId: string): Promise<HealthProblem[]> {
    const problem = this.problems.get(problemId);
    if (!problem || !problem.relatedProblems) return [];

    return problem.relatedProblems
      .map(id => this.problems.get(id))
      .filter((p): p is HealthProblem => p !== undefined);
  }

  async searchProblems(query: string): Promise<HealthProblem[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.problems.values()).filter(problem =>
      Object.values(problem.name).some(name =>
        name.toLowerCase().includes(lowerQuery)
      )
    );
  }
}

export const storage = new MemStorage();
