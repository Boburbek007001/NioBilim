import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all body systems
  app.get("/api/systems", async (req, res) => {
    try {
      const systems = await storage.getAllSystems();
      res.json(systems);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch systems" });
    }
  });

  // Get single system by ID
  app.get("/api/systems/:id", async (req, res) => {
    try {
      const system = await storage.getSystemById(req.params.id);
      if (!system) {
        return res.status(404).json({ error: "System not found" });
      }
      res.json(system);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch system" });
    }
  });

  // Get featured problems - must come before parameterized routes
  app.get("/api/problems/featured", async (req, res) => {
    try {
      const problems = await storage.getFeaturedProblems();
      res.json(problems);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch featured problems" });
    }
  });

  // Get related problems - must come before parameterized routes
  app.get("/api/problems/related/:problemId", async (req, res) => {
    try {
      const problems = await storage.getRelatedProblems(req.params.problemId);
      res.json(problems);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch related problems" });
    }
  });

  // Get single problem by ID
  app.get("/api/problem/:id", async (req, res) => {
    try {
      const problem = await storage.getProblemById(req.params.id);
      if (!problem) {
        return res.status(404).json({ error: "Problem not found" });
      }
      res.json(problem);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch problem" });
    }
  });

  // Get problems by system
  app.get("/api/problems/:systemId", async (req, res) => {
    try {
      const problems = await storage.getProblemsBySystem(req.params.systemId);
      res.json(problems);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch problems" });
    }
  });

  // Search problems
  app.get("/api/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Query parameter required" });
      }
      const problems = await storage.searchProblems(query);
      res.json(problems);
    } catch (error) {
      res.status(500).json({ error: "Failed to search problems" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
