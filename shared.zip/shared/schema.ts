import { z } from "zod";

// Severity levels for health problems
export enum Severity {
  LOW = "low",
  MODERATE = "moderate",
  HIGH = "high",
  CRITICAL = "critical"
}

// Body System interface
export interface BodySystem {
  id: string;
  name: Record<string, string>; // Multilingual names
  icon: string;
  description: Record<string, string>;
  problemCount: number;
  color: string; // Hex color for theming
}

// Health Problem interface
export interface HealthProblem {
  id: string;
  systemId: string;
  name: Record<string, string>;
  severity: Severity;
  description: Record<string, string>;
  quickSummary: Record<string, string>;
  overview: Record<string, string>;
  causes: Record<string, string[]>;
  symptoms: Record<string, string[]>;
  solutions: Record<string, string[]>;
  prevention: Record<string, string[]>;
  relatedProblems: string[]; // IDs of related problems
  isFeatured?: boolean; // For overweight, depression, stress
}

// Language option
export interface Language {
  code: string;
  name: string;
  nativeName: string;
}

// Search result
export interface SearchResult {
  type: "system" | "problem";
  id: string;
  name: string;
  systemId?: string;
  systemName?: string;
  matchedText: string;
}

// Export types for frontend use
export type { BodySystem, HealthProblem, Language, SearchResult };
