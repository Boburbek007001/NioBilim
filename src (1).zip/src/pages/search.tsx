import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import type { HealthProblem } from '@shared/schema';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Search, ArrowLeft, ArrowRight } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Link } from 'wouter';

export default function SearchPage() {
  const { t, i18n } = useTranslation();
  const [location, setLocation] = useLocation();
  const currentLang = i18n.language;

  // Get query from URL
  const urlParams = new URLSearchParams(window.location.search);
  const initialQuery = urlParams.get('q') || '';
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [activeQuery, setActiveQuery] = useState(initialQuery);

  // Update search query when URL changes
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const q = urlParams.get('q') || '';
    if (q && q !== activeQuery) {
      setSearchQuery(q);
      setActiveQuery(q);
    }
  }, [location]);

  const { data: results, isLoading } = useQuery<HealthProblem[]>({
    queryKey: ['/api/search', activeQuery],
    queryFn: async () => {
      const response = await fetch(`/api/search?q=${encodeURIComponent(activeQuery)}`);
      if (!response.ok) throw new Error('Search failed');
      return response.json();
    },
    enabled: activeQuery.length > 0,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setActiveQuery(searchQuery);
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <div className="min-h-screen">
      <section className="bg-accent/30 py-12">
        <div className="container mx-auto px-4 md:px-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4" data-testid="button-back-home">
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('backToHome')}
            </Button>
          </Link>

          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            {t('searchProblems')}
          </h1>

          <form onSubmit={handleSearch} className="max-w-2xl">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder={t('searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-14 text-lg"
                data-testid="input-search-query"
              />
              <Button
                type="submit"
                className="absolute right-2 top-1/2 transform -translate-y-1/2"
                data-testid="button-submit-search"
              >
                {t('searchProblems')}
              </Button>
            </div>
          </form>
        </div>
      </section>

      <section className="py-12">
        <div className="container mx-auto px-4 md:px-6">
          {activeQuery && (
            <p className="text-lg text-muted-foreground mb-6">
              {isLoading ? 'Searching...' : `${results?.length || 0} results for "${activeQuery}"`}
            </p>
          )}

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/4" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-16 w-full mb-4" />
                    <Skeleton className="h-10 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : results && results.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((problem) => (
                <Card 
                  key={problem.id}
                  className="hover-elevate active-elevate-2 transition-all"
                  data-testid={`card-result-${problem.id}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <CardTitle className="text-xl">
                        {problem.name[currentLang] || problem.name['en']}
                      </CardTitle>
                      <Badge 
                        variant={
                          problem.severity === 'critical' ? 'destructive' :
                          problem.severity === 'high' ? 'destructive' :
                          'secondary'
                        }
                        data-testid={`badge-severity-${problem.id}`}
                      >
                        {t(problem.severity)}
                      </Badge>
                    </div>
                    <CardDescription>
                      {problem.quickSummary[currentLang] || problem.quickSummary['en']}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Link href={`/problem/${problem.id}`}>
                      <Button variant="outline" className="w-full" data-testid={`button-view-result-${problem.id}`}>
                        {t('learnMore')}
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : activeQuery ? (
            <div className="text-center py-12">
              <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" data-testid="icon-no-results" />
              <h3 className="text-xl font-semibold mb-2">No results found</h3>
              <p className="text-muted-foreground mb-6">
                Try searching with different keywords
              </p>
              <Link href="/">
                <Button data-testid="button-browse-home">
                  {t('browseSystems')}
                </Button>
              </Link>
            </div>
          ) : (
            <div className="text-center py-12">
              <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" data-testid="icon-start-search" />
              <h3 className="text-xl font-semibold mb-2">Start your search</h3>
              <p className="text-muted-foreground">
                Enter a health condition or symptom to search
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
