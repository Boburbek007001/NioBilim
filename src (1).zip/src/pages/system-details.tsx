import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { useRoute, Link } from 'wouter';
import type { BodySystem, HealthProblem } from '@shared/schema';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, ArrowRight, Search, AlertCircle } from 'lucide-react';
import { useState } from 'react';

export default function SystemDetails() {
  const { t, i18n } = useTranslation();
  const [, params] = useRoute('/system/:id');
  const systemId = params?.id;
  const currentLang = i18n.language;
  const [searchFilter, setSearchFilter] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');

  const { data: system, isLoading: systemLoading } = useQuery<BodySystem>({
    queryKey: ['/api/systems', systemId],
    enabled: !!systemId,
  });

  const { data: problems, isLoading: problemsLoading } = useQuery<HealthProblem[]>({
    queryKey: ['/api/problems', systemId],
    enabled: !!systemId,
  });

  const filteredProblems = problems?.filter(problem => {
    const matchesSearch = !searchFilter || 
      (problem.name[currentLang] || problem.name['en']).toLowerCase().includes(searchFilter.toLowerCase());
    const matchesSeverity = severityFilter === 'all' || problem.severity === severityFilter;
    return matchesSearch && matchesSeverity;
  });

  if (!systemId) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-destructive" />
          <h1 className="text-2xl font-bold mb-2">System not found</h1>
          <Link href="/">
            <Button data-testid="button-back-home">
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('backToHome')}
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="bg-accent/30 py-12">
        <div className="container mx-auto px-4 md:px-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4" data-testid="button-back">
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('backToHome')}
            </Button>
          </Link>
          
          {systemLoading ? (
            <div>
              <Skeleton className="h-12 w-3/4 mb-4" />
              <Skeleton className="h-6 w-1/2 mb-2" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : (
            <>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                {system?.name[currentLang] || system?.name['en']}
              </h1>
              <Badge variant="secondary" className="mb-4" data-testid="badge-problem-count">
                {system?.problemCount}+ {t('problems')}
              </Badge>
              <p className="text-lg text-muted-foreground max-w-3xl">
                {system?.description[currentLang] || system?.description['en']}
              </p>
            </>
          )}
        </div>
      </section>

      {/* Problems Section */}
      <section className="py-12">
        <div className="container mx-auto px-4 md:px-6">
          {/* Filters */}
          <div className="mb-8 flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder={t('searchPlaceholder')}
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="pl-10"
                data-testid="input-filter-search"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              {['all', 'low', 'moderate', 'high', 'critical'].map((severity) => (
                <Button
                  key={severity}
                  variant={severityFilter === severity ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSeverityFilter(severity)}
                  data-testid={`button-filter-${severity}`}
                >
                  {severity === 'all' ? 'All' : t(severity)}
                </Button>
              ))}
            </div>
          </div>

          {/* Problems Grid */}
          {problemsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/4" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-16 w-full mb-4" />
                    <Skeleton className="h-10 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredProblems && filteredProblems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProblems.map((problem) => (
                <Card 
                  key={problem.id}
                  className="hover-elevate active-elevate-2 transition-all"
                  data-testid={`card-problem-${problem.id}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <CardTitle className="text-xl">
                        {problem.name[currentLang] || problem.name['en']}
                      </CardTitle>
                      <Badge 
                        variant={
                          problem.severity === 'critical' ? 'destructive' :
                          problem.severity === 'high' ? 'destructive' :
                          problem.severity === 'moderate' ? 'secondary' :
                          'secondary'
                        }
                        data-testid={`badge-severity-${problem.id}`}
                      >
                        {t(problem.severity)}
                      </Badge>
                    </div>
                    <CardDescription>
                      {problem.quickSummary[currentLang] || problem.quickSummary['en']}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Link href={`/problem/${problem.id}`}>
                      <Button variant="outline" className="w-full" data-testid={`button-view-${problem.id}`}>
                        {t('learnMore')}
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">No problems found</h3>
              <p className="text-muted-foreground">Try adjusting your filters</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
