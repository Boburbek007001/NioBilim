import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { useRoute, Link } from 'wouter';
import type { HealthProblem } from '@shared/schema';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ArrowLeft, AlertCircle, CheckCircle2, Info } from 'lucide-react';

export default function ProblemDetails() {
  const { t, i18n } = useTranslation();
  const [, params] = useRoute('/problem/:id');
  const problemId = params?.id;
  const currentLang = i18n.language;

  const { data: problem, isLoading } = useQuery<HealthProblem>({
    queryKey: ['/api/problem', problemId],
    enabled: !!problemId,
  });

  const { data: relatedProblems } = useQuery<HealthProblem[]>({
    queryKey: ['/api/problems/related', problemId],
    enabled: !!problemId && !!problem,
  });

  if (!problemId) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-destructive" />
          <h1 className="text-2xl font-bold mb-2">Problem not found</h1>
          <Link href="/">
            <Button data-testid="button-back-home">
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('backToHome')}
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Skeleton className="h-8 w-32 mb-8" />
        <Skeleton className="h-12 w-3/4 mb-4" />
        <Skeleton className="h-6 w-1/4 mb-8" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!problem) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-destructive" />
          <h1 className="text-2xl font-bold mb-2">Problem not found</h1>
          <Link href="/">
            <Button data-testid="button-back-home">
              <ArrowLeft className="mr-2 h-4 w-4" />
              {t('backToHome')}
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 md:px-6 py-8 max-w-5xl">
        <Link href={`/system/${problem.systemId}`}>
          <Button variant="ghost" className="mb-6" data-testid="button-back">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to System
          </Button>
        </Link>

        {/* Problem Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between gap-4 mb-4 flex-wrap">
            <h1 className="text-4xl md:text-5xl font-bold" data-testid="text-problem-name">
              {problem.name[currentLang] || problem.name['en']}
            </h1>
            <Badge 
              variant={
                problem.severity === 'critical' ? 'destructive' :
                problem.severity === 'high' ? 'destructive' :
                'secondary'
              }
              className="text-lg px-4 py-2"
              data-testid="badge-severity"
            >
              {t('severity')}: {t(problem.severity)}
            </Badge>
          </div>

          <Alert className="bg-accent/50">
            <Info className="h-4 w-4" />
            <AlertDescription className="text-base">
              {problem.quickSummary[currentLang] || problem.quickSummary['en']}
            </AlertDescription>
          </Alert>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="overview" className="mb-12">
          <TabsList className="grid w-full grid-cols-5 mb-8" data-testid="tabs-content">
            <TabsTrigger value="overview" data-testid="tab-overview">{t('overview')}</TabsTrigger>
            <TabsTrigger value="causes" data-testid="tab-causes">{t('causes')}</TabsTrigger>
            <TabsTrigger value="symptoms" data-testid="tab-symptoms">{t('symptoms')}</TabsTrigger>
            <TabsTrigger value="solutions" data-testid="tab-solutions">{t('solutions')}</TabsTrigger>
            <TabsTrigger value="prevention" data-testid="tab-prevention">{t('prevention')}</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{t('overview')}</CardTitle>
              </CardHeader>
              <CardContent className="prose dark:prose-invert max-w-none">
                <p className="text-base leading-relaxed">
                  {problem.overview[currentLang] || problem.overview['en']}
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="causes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{t('causes')}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {(problem.causes[currentLang] || problem.causes['en'])?.map((cause, index) => (
                    <li key={index} className="flex gap-3">
                      <AlertCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-base">{cause}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="symptoms" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{t('symptoms')}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {(problem.symptoms[currentLang] || problem.symptoms['en'])?.map((symptom, index) => (
                    <li key={index} className="flex gap-3">
                      <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                      <span className="text-base">{symptom}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="solutions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{t('solutions')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {(problem.solutions[currentLang] || problem.solutions['en'])?.map((solution, index) => (
                    <div key={index} className="flex gap-3 p-4 rounded-lg bg-accent/30">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                        {index + 1}
                      </div>
                      <p className="text-base flex-1">{solution}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="prevention" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{t('prevention')}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {(problem.prevention[currentLang] || problem.prevention['en'])?.map((item, index) => (
                    <li key={index} className="flex gap-3">
                      <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-base">{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Medical Disclaimer */}
        <Alert className="mb-8">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {t('disclaimer')}
          </AlertDescription>
        </Alert>

        {/* Related Problems */}
        {relatedProblems && relatedProblems.length > 0 && (
          <div>
            <h2 className="text-2xl font-semibold mb-6">{t('relatedProblems')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {relatedProblems.slice(0, 3).map((related) => (
                <Card 
                  key={related.id}
                  className="hover-elevate active-elevate-2"
                  data-testid={`card-related-${related.id}`}
                >
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {related.name[currentLang] || related.name['en']}
                    </CardTitle>
                    <CardDescription>
                      {related.quickSummary[currentLang] || related.quickSummary['en']}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Link href={`/problem/${related.id}`}>
                      <Button variant="outline" size="sm" className="w-full" data-testid={`button-related-${related.id}`}>
                        {t('learnMore')}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
