import { useTranslation } from 'react-i18next';
import { Activity } from 'lucide-react';

export function Footer() {
  const { t } = useTranslation();

  return (
    <footer className="border-t bg-card mt-16">
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Activity className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">{t('siteName')}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {t('tagline')}
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">{t('bodySystems')}</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="hover-elevate rounded-md px-2 py-1">
                <a href="/#systems" data-testid="link-footer-systems">
                  {t('browseSystems')}
                </a>
              </li>
              <li className="hover-elevate rounded-md px-2 py-1">
                <a href="/#featured" data-testid="link-footer-featured">
                  {t('featuredTopics')}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">{t('aboutUs')}</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="hover-elevate rounded-md px-2 py-1">
                <a href="#" data-testid="link-footer-about">
                  {t('aboutUs')}
                </a>
              </li>
              <li className="hover-elevate rounded-md px-2 py-1">
                <a href="#" data-testid="link-footer-contact">
                  {t('contactUs')}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="hover-elevate rounded-md px-2 py-1">
                <a href="#" data-testid="link-footer-privacy">
                  {t('privacyPolicy')}
                </a>
              </li>
              <li className="hover-elevate rounded-md px-2 py-1">
                <a href="#" data-testid="link-footer-terms">
                  {t('termsOfService')}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t">
          <p className="text-sm text-muted-foreground text-center">
            {t('disclaimer')}
          </p>
          <p className="text-xs text-muted-foreground text-center mt-4">
            © 2025 {t('siteName')}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
